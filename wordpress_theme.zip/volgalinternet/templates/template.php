<?php
get_header();
?>

<section class="typical-services">
	<div class="container">
		<div class="section-title">
			<h1>Интернет на дачу</h1>
			<hr class="dash">
		</div>
	</div>
</section>

<section>
	<div class="container">
		<div class="unlim-internet">
			<div class="section-title">
				<h2>Для чего подойдёт наш <b class="lite">безлимитный</b> интернет</h2>
			</div>
			
			<div class="cards-internet">
				<div class="card-internet-block">
					<img src="img/4kfilms.png" alt="">
					<h3>Фильмы в 4К</h3>
					<p>просмотр в Full hd и 4к без зависаний</p>
				</div>
				<div class="card-internet-block">
					<img src="img/youtube.png" alt="youtube">
					<h3>Видео</h3>
					<p>
						будут загружаться моментально
					</p>
				</div>
				<div class="card-internet-block">
					<img src="img/work.png" alt="work">
					<h3>Работа</h3>
					<p>
						удаленно, ip телефония, облачные сервисы, 1С
					</p>
				</div>
				<div class="card-internet-block">
					<img src="img/games.png" alt="games">
					<h3>Онлайн игры</h3>
					<p>
						World of Tanks, CS:GO и другие онлайн игры без тормозов
					</p>
				</div>
				<div class="card-internet-block">
					<img src="img/videosearch.png" alt="videosearch">
					<h3>Видеонаблюдение</h3>
					<p>
						удаленный просомтр видео с камер видеонаблюдения
					</p>
				</div>
				<div class="card-internet-block">
					<img src="img/skype.png" alt="skype">
					<h3>Видеосвязь</h3>
					<p>
						аудио и видео звонки через месседжеры
					</p>
				</div>
			</div>
			<span class="button button-black">Узнать подробнее</span>
		</div>	
	</div>
</section>
<hr class="hr">
<section class="stages-body">
	<div class="container">
		<div class="section-title">
			<h2>Этапы работы</h2>
		</div>
		<div class="stages">
			<div class="stage">
				<span class="circle">1</span>
				<h3>Оставьте заявку</h3>
			</div>
			<div class="stage">
				<span class="circle">2</span>
				<h3>Выезд монтажника на замер</h3>
			</div>
			<div class="stage">
				<span class="circle">3</span>
				<h3>Подбор оборудования</h3>
			</div>
			<div class="stage">
				<span class="circle">4</span>
				<h3>Монтажные работы</h3>
			</div>
			<div class="stage">
				<span class="circle">5</span>
				<h3>Договор и оплата</h3>
			</div>
		</div>
	</div>
</section>
<hr class="hr">
<section class="stages-body">
	<div class="container">
		<div class="section-title">
			<h2>Что входит в стандартный монтаж</h2>
		</div>
		<div class="cards img-fix">
				<!-- 1 -->
				<div class="card">
					
					<img src="img/antenna.png" alt="antenna" class="card-image">
					<p class="txt">Наружная антенна</p>
				</div>
				<!-- 2 -->
				<div class="card">
					<img src="img/modem.png" alt="modem" class="card-image">
					<p class="txt">Програмируемый модем</p>
				</div>
				<!-- 3 -->
				<div class="card">
					<img src="img/cabel.png" alt="cabel" class="card-image">
					<p class="txt">Высококачественный кабель</p>
				</div>
				<!-- 4 -->
				<div class="card">
					<img src="img/router.png" alt="router" class="card-image">
					<p class="txt">Мощный Wi-Fi роутер</p>
				</div>
				<!-- 5 -->
				<div class="card">
					<img src="img/drill.png" alt="router" class="card-image last-child">
					<p class="txt">Монтажные работы под ключ</p>
				</div>
			</div>
	</div>
</section>
<hr class="hr">
<section class="costs-typing">
	<div class="container">
		
		<div class="panel-costs-typing">
			<div class="rectangle-yellow"></div>
			<div class="rectangle-brown"></div>
		</div>

		<div class="section-title">
			<h2>Стоимость</h2>
		</div>
		
		<div class="cards-internet">
			<div class="card-internet-block">
				<img src="img/unlim-black.png" alt="">
				<h3>Безлимитный тариф</h3>
				<p></p>
			</div>
			<div class="card-internet-block">
				<img src="img/wife.png" alt="youtube">
				<h3>Зона покрытия WiFi от 100м2</h3>
				<p>
					
				</p>
			</div>
			<div class="card-internet-block">
				<img src="img/speed2.png" alt="work">
				<h3>Скорость до 100Мбит/с</h3>
				<p></p>
			</div>
			<div class="card-internet-block">
				<img src="img/mounting2.png" alt="games">
				<h3>Монтаж под ключ за 1 день</h3>
				<p></p>
			</div>
			<div class="card-internet-block">
				<img src="img/big-car.png" alt="videosearch">
				<h3>Видеонаблюдение</h3>
				<p>
					до 100км от города +1000р
				</p>
			</div>
			<div class="card-internet-block">
				<img src="img/big-car.png" alt="skype">
				<h3>Транспортный расход:</h3>
				<p>
					до 300км от города +2000р
				</p>
			</div>
		</div>
		<p class="discount-costs-typing">от 17 000 Р</p>
		
		<div class="buttons-typing">
			<span class="button button-black-left">Выбрать тариф</span>
			<span class="button button-yellow-right">Оставить заявку</span>
		</div>
	</div>
</section>
<hr class="hr">

<?php
get_footer();