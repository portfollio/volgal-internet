<?php
get_header();
?>

<section class="typical-services">
	<div class="container">
		<div class="section-title">
			<h1>Контакты</h1>
			<hr class="dash">
		</div>
	</div>
</section>

<section>
	<div class="container">
		<div class="contacts">
			<div class="links-title">
				<h2><a href="#!">КОНТАКТЫ</a></h2>	
			</div>
			<hr class="dash">
			
			<!-- карты -->
			<div class="location-info">
				<img src="<?php echo get_template_directory_uri()?>/assets/img/pin.svg" alt="loc">
				<h3>Адрес</h3>
				<p>район Ворошиловский, ул.Козловская, 9 Волгоград Россия офис</p>
			</div>
			<!-- <map name="map">
				
			</map> -->
			<div class="location-info">
				<img src="<?php echo get_template_directory_uri()?>/assets/img/pin.svg" alt="loc">
				<h3>Адрес</h3>
				<p>Ардатовская д.29, Волгоград, Россия розничный магазин</p>
			</div>
			<!-- <map name="map">
				
			</map> -->
			<!-- /карты -->
			<div class="contact-blocks">
				<div class="phone">
					<div class="contact-icon-label">
						<img src="<?php echo get_template_directory_uri()?>/assets/img/call.svg" alt="phone">
						<h3>Телефоны</h3>
					</div>
					<div class="phone-links">
						<p>+7 (8442) 61-28-01</p>
						<p>+7 (904) 361-72-36</p>
					</div>
				</div>
				<div class="mail">
					<div class="contact-icon-label">
						<img src="<?php echo get_template_directory_uri()?>/assets/img/email.svg" alt="mail">
						<h3>E-MAIL</h3>
					</div>
					<a href="#!" class="mail-link">info@volga-internet.ru</a>
				</div>	
			</div>
		</div>
	</div>
</section>

<hr class="hr">

<?php
get_footer();