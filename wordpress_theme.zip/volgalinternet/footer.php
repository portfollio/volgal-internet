<footer>
	<div class="container">
		<p class="footer">
			2015 - 2019 © Подключение безлимитного интернета в Волгограде и Волгоградской области<br>
			61-28-01 | +7 (904) 361-72-36
		</p>
	</div>
</footer>



<?php wp_footer(); ?>

</body>
</html>
