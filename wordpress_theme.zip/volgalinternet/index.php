<?php
get_header();
wp_nav_menu();
?>


<main>
	<section class="titles">
		<div class="container">
			<div class="titles_first">
				<h1>Стабильный безлимитный интернет</h1>
				<h2>В частный дом за 1 день</h2>
				<span>Скидка на подключение - 2000 Руб</span>
			</div>
			<a class="button" href="#">Узнать подробнее</a>
		</div>
	</section>
	<hr class="hr">
	<section class="services">
		<div class="container">
			<div class="title">
				<h1>
					ИНТЕРНЕТ В ЧАСТНЫЕ ДОМА В ВОЛГОГРАДЕ И ОБЛАСТИ
				</h1>
				<hr class="dash">
				<h2>
					ПРЕИМУЩЕСТВА ОЧЕВИДНЫ
				</h2>
				<p>
					Мы подключаем беспроводной, быстрый интернет даже в местах с отсутствием связи
				</p>
				<hr class="dash">
			</div>
			<div class="services heading clearfix">
				<!-- начало блоков -->
				<div class="services_item">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/unlim-circle.png" alt="unlim">
					<h3>E-Безлимитный тариф</h3>
					<p>
						от 800Р в месяц
					</p>
				</div>
				<div class="services_item">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/mounting.png" alt="mounting">
					<h3>Монтаж за 3 часа</h3>
					<p>
						выезд специалиста в день обращения бесплатно
					</p>
				</div>
				<div class="services_item">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/cost.png" alt="cost">
					<h3>Без предоплаты</h3>
					<p>
						оплата по результату
					</p>
				</div>
				<div class="services_item">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/high-speed.png" alt="high-speed">
					<h3>Высокая скорость</h3>
					<p>
						до 100 мбит/сек
					</p>
				</div>
			</div>
				<!-- 4 блока -->
			<div class="heading clearfix">
				<div class="services_item">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/garantii.png" alt="garantii">
					<h3>Гарантия</h3>
					<p>
						1 год на оборудование и работы
					</p>
				</div>
				<div class="services_item">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/technical-support.png" alt="technical-support">
					<h3>Тех.поддержка 24/7</h3>
					<p>
						от провайдера
					</p>
				</div>
				<div class="services_item">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/money.png" alt="money">
					<h3>Наличный и безналичный</h3>
					<p>
						расчет
					</p>
				</div>
				<div class="services_item">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/location.png" alt="location">
					<h3>Подключение по Волгограду и области</h3>
					<p>
						в любой деревне, поселке, городе, на трассе 
					</p>
				</div>
			</div>
		</div>
	</section>
	
	<hr class="hr">

	<section class="technology">	
		<div class="container">
			<div class="section-title">
				<h2>ТЕХНОЛОГИЯ ПОДКЛЮЧЕНИЯ</h2>
				<span>Плюсы и минусы различных технологий подключения интернета в местах отдаленных от города</span>
			</div>

			<hr class="dash">
			
			<div class="cards heading">
				<div class="card">
					
					<img src="<?php echo get_template_directory_uri()?>/assets/img/unlimit.png" alt="unlimit" class="card-image">
					<div class="card-info">
						<div class="card-technology-info">
							<h3>1.Подключение от компании ВОЛГА-интернет</h3>
							<span><b>Плюсы:</b><br>
							<p>- стабильная работа</p>
							<p>- скорость до 100 Мбит/сек</p>
							<p>- безлимитный тариф </p>
							<p>- установка за 1 день</p>
							<p>- низкая стоимость подключения</p>
							<p>- подключение в любой точке Волгоградской обл.</p>
						</span>
						</div>
					</div>
				</div>
			<!-- 2 -->
				<div class="card">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/telephone.png" alt="telephone" class="card-image">
					
					<div class="card-info">
						<div class="card-technology-info">
							<h3>2.ADSL</h3>
							<span><b>Минусы:</b><br>
								<p>- устаревшая технология</p>
								<p>- требуется телефонная линия</p>
								<p>- скорость не более 2Мбит/сек</p>
								<b>Плюсы:</b><br>
								<p>- подойдет для проверки почты</p>
							</span>
						</div>
					</div>
				</div>
			<!-- 3 -->
				<div class="card">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/usb.png" alt="USB" class="card-image">
				
					<div class="card-info">
						<div class="card-technology-info">
							<h3>3.Мобильный интернет через модемы</h3>
							<span><b>Минусы:</b><br>
								<p>- малый диапазон работы</p>
								<p>- скорость не постоянна (0-20Мбит/сек)</p>
								<p>- нет безлимитных тарифов</p>
								<p>- иногда пропадает соединение</p>
								<b>Плюсы:</b><br>
								<p>- бюджетный вариант подключения к интернет</p>
							</span>
						</div>
					</div>
				</div>
			<!-- 4 -->
				<div class="card">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/optical-fiber.png" alt="optical" class="card-image">
				
					<div class="card-info">
						<div class="card-technology-info">
							<h3>4.Проводной интернет (оптоволокно)</h3>
							<span>
								<b>Минусы:</b><br>
								<p>- не всегда есть возможность подключить</p>
								<p>- высокая стоимость (от 40 тыс. руб. и более)</p>
								<p>- большой срок по реализации подключения</p>
								<b>Плюсы:</b><br>
								<p>- стабильная работа, высокая скорость</p>
							</span>
						</div>
					</div>
				</div>
			<!-- 5 -->
				<div class="card">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/satellite.png" alt="satellite" class="card-image">
					
					<div class="card-info">
						<div class="card-technology-info">
							<h3>5.Спутниковый интернет</h3>
							<span>
								<b>Минусы:</b><br>
								<p>- высокая стоимость оборудования и абон. платы</p>
								<p>- качество соединения зависит от погодных условий</p>
								<p>- нет безлимитных тарифов</p>
								<b>Плюсы:</b><br>
								<p>- подключение в любой точке земного шара</p>
							</span>
						</div>
					</div>
				</div>
			</div>	
		</div>
	</section>
	
	<hr class="hr">

	<section>
		<div class="container">
			<div class="about">
				<div class="section-title">
					<h2>О ТЕХНОЛОГИИ</h2>
					<p>VOLGA-internet</p>
					<span>
						Устанавливается наружная антенна на уровень 2ого этажа и выше, проводится высококачественный кабель в помещение, обжимается специальными разъемами, подключается програмируемый модем с универсальной прошивкой под любых операторов с безлимитными тарифами, подключается и настраивается мощный Wi-Fi роутер с 4 антеннами (площадь покрытия беспроводной сети до 150м2). Производится настройка интернет канала на радиочастотах 800-2600Мгц.
					</span>
				</div>
				<span class="composition">состав комплекта</span>

				<div class="cards cards-about">
					<!-- 1 -->
					<div class="card card-about">
						
						<img src="<?php echo get_template_directory_uri()?>/assets/img/antenna.png" alt="antenna" class="card-image">
						<p class="txt">Наружная антенна</p>
					</div>
					<!-- 2 -->
					<div class="card card-about">
						<img src="<?php echo get_template_directory_uri()?>/assets/img/modem.png" alt="modem" class="card-image">
						<p class="txt">Програмируемый модем</p>
					</div>
					<!-- 3 -->
					<div class="card card-about">
						<img src="<?php echo get_template_directory_uri()?>/assets/img/cabel.png" alt="cabel" class="card-image">
						<p class="txt">Высококачественный кабель</p>
					</div>
					<!-- 4 -->
					<div class="card card-about">
						<img src="<?php echo get_template_directory_uri()?>/assets/img/router.png" alt="router" class="card-image">
						<p class="txt">Мощный Wi-Fi роутер</p>
					</div>
				</div>
			</div>	
		</div>
	</section>

	<hr class="hr">

	<section class="price">
		<div class="container">
			<div class="section-title">
				<h2>СТОИМОСТЬ ПОДКЛЮЧЕНИЯ</h2>
			</div>
			<div class="cards">
				<div class="card card-price">
					<div class="card-price-block">
						<div class="rectangle">1</div>
						<h3>САМОСТОЯТЕЛЬНАЯ УСТАНОВКА</h3>
						<h4>12 000 Р</h4>
						<a><p>ЗАКАЗАТЬ</p></a>
					</div>
					<div class="description">
						<b>Состав комплекта:</b><br>
						<p>- Антенное оборудование</p>
						<p>- Программируемый модем</p>
						<p>- Wi-Fi роутер ZBT-WE3326</p>
						<p>- Безлимитный тариф от 350р/мес.</p>
						<p>- Скорость: до 100Мбит/с</p>
						<p>- Доставка бесплатно</p>
						<p>- Инструкция по установке</p>
						<p>- Гарантия на оборудование 1 год</p>
						<p><s>Монтажные работы</s></p>
					</div>
				</div>
				<div class="card card-price">
					<div class="card-price-block">
						<div class="rectangle">2</div>
						<h3>МОНТАЖ «ПОД КЛЮЧ»</h3>
						<h4>15 000Р <s>17 000 Р</s></h4>
						<a><p>ЗАКАЗАТЬ</p></a>
					</div>
					<div class="description">
						<div class="description-block">
							<b>Состав комплекта:</b><br>
							<p>- Антенное оборудование</p>
							<p>- Программируемый модем</p>
							<p>- Wi-Fi роутер ZBT-WE3326</p>
							<p>- Безлимитный тариф 800 р/мес.</p>
							<p>- Скорость: до 100Мбит/с</p>
							<p>- Доставка бесплатно</p>
							<p>- Инструкция по установке</p>
							<p>- Гарантия на оборудование 1 год</p>
						</div>
						<div class="description-block">
							<b>Монтажные работы:</b><br>
							<p>- Выезд специалиста</p>
							<p>- Проведение тех. обследования</p>
							<p>- Монтаж и настройка оборудования</p>
							<p>- Гарантия на работы 5 лет</p>
							<p>- Транспортный расход</p>
							<p>(до 30км от г. Волгограда)</p>
						</div>
					</div>
				</div>
				<div class="card card-price">
					<div class="card-price-block">
						<div class="rectangle">Доп.Услуги</div>
						<h3>ПРАЙС НА ДОП. УСЛУГИ</h3>
					</div>
					<div class="description">
						<div class="description-block">
							<b>Выезд без монтажа:</b><br>
							<p>Проведение тех. обследования с замером скорости - 3000 руб</p>
						</div>
						
						<div class="description-block">
							<b>Транспортный расход:</b><br>
							<p>до 30км - 0 руб</p>
							<p>(входит в стоимость установки)</p>
							<p>30км -100км - 1000руб</p>
							<p>100км - 200км - 2000руб</p>
						</div>
						
						<div class="description-block">
							<b>Дополнительный Wi-Fi роутер:</b><br>
							<p>2000руб (с настройкой)</p>
						</div>
						<div class="description-block">
							<b>Телевиденье IPTV:</b><br>
							<p>Приставка X96 Mini 2/16 - 3500руб</p>
							<p>150 каналов - 0 руб</p>
							<p>400 каналов - 70р/мес</p>	
						</div>
						
						<div class="description-block">
							<b>Монтаж ЛВС:</b><br>
							<p>от 100руб/м</p>
						</div>
					</div>
				</div>
			</div>
			<div class="info">
				* Комплект с максимальной мощностью (мощность до 30dbi) для самостоятельной установки интернета за городом на скорости до 100Мбит/с. Подходит для объектов отдаленных от вышек провайдера не более 12км, в комплект входит wi-fi роутер с зоной покрытия до 150м2, безлимитный тариф, доствка бесплатно (до пункта выдачи транспортной компании), помощь в установке от тех. специалистов нашей компании.
			</div>
			<a href="#!"><span class="button button-black">Заказать</span></a>
			<a href="#!"><span class="button button-cheap">Заказать со скидкой</span></a>
		</div>
	</section>

	<hr class="hr">
	
	<section class="guarantee">
		<div class="container">
			<div class="section-title">
				<h2>
					Гарантии
				</h2>
			</div>
			<div class="cards-guarantee clearfix">
				<div class="card-guarantee-block">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/service.png" alt="service">
					<h3>Техническое обслуживание</h3>
					<p>
						проводится в течении 1 года бесплатно по гранатии. Если оборудование перестало работать, то вы звоните нам. Наши специалисты решают ситуацию удаленно либо выезжаю на объект.
					</p>
				</div>
				<div class="card-guarantee-block">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/guarantee.png" alt="guarantee">
					<h3>Гарантия качества</h3>
					<p>
						мы гарантируем качественное выполнение работ по монтажу и настройке оборудования на высшем уровне. Мы хотим что бы нас могли смело рекомендовать.
					</p>
				</div>
				<div class="card-guarantee-block">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/decor.png" alt="decor">
					<h3>Официальное оформление</h3>
					<p>
						работаем официально по договору с физическими и юридическими лицами. Все тарифы от провайдеров заключаются на официальной основе на прямую с конечным клиентом.
					</p>
				</div>
			</div>
		</div>
	</section>

	<hr class="hr">

	<section class="stages-body">
		<div class="container">
			<div class="section-title">
				<h2>Этапы работы</h2>
			</div>
			<div class="stages">
				<div class="stage">
					<span class="circle">1</span>
					<h3>Оставьте заявку</h3>
				</div>
				<div class="stage">
					<span class="circle">2</span>
					<h3>Выезд монтажника на замер</h3>
				</div>
				<div class="stage">
					<span class="circle">3</span>
					<h3>Подбор оборудования</h3>
				</div>
				<div class="stage">
					<span class="circle">4</span>
					<h3>Монтажные работы</h3>
				</div>
				<div class="stage">
					<span class="circle">5</span>
					<h3>Договор и оплата</h3>
				</div>
			</div>
		</div>
	</section>
	
	<hr class="hr">

	<section class="about-us">
		<div class="container">
			<div class="about-company">
				<div class="about-company-block">
					<h2>О НАС</h2>
					<p>Мы монтажная компания по установке интернета в частные дома. Подключим интернет в любой дом по Волгограду и ОБЛАСТИ в течении 1 дня. Опыт работы более 10 лет, используем сертефицированое оборудование, предоставляем гарантию 1 год по договору.</p>	
				</div>
				<img src="<?php echo get_template_directory_uri()?>/assets/img/icons-about-us.png" alt="icons">
			</div>
			
		</div>
	</section>

	<hr class="hr">
	
	<section class="lnk">
		<div class="container">
			<h2>Смотрите так же:</h2>
			<div class="links">
				<div class="links-blok">
					<a href="#!"><p>Интернет в Среднеахтубинском районе</p></a>
					<a href="#!"><p>Интернет в коттедж</p></a>
					<a href="#!"><p>Интернет в частный сектор</p></a>
					<a href="#!"><p>Усилитель интернета 4G для дачи</p></a>
					<a href="#!"><p>Усилитель интернета для дачи</p></a>
				</div>
				<div class="links-blok">
					<a href="#!"><p>Интернет 3G/4G для дачи</p></a>
					<a href="#!"><p>Интернет в деревне</p></a>
					<a href="#!"><p>Интернет в частный дом волгоград советский район</p></a>
					<a href="#!"><p>Интернет на дачу</p></a>
					<a href="#!"><p>Интернет в Красноармейском районе</p></a>
				</div>
				<div class="links-blok">
					<a href="#!"><p>Интернет в Краснооктябрьском районе</p></a>
					<a href="#!"><p>Интернет в частный дом волгоград кировский район</p></a>
					<a href="#!"><p>Интернет в частный дом волгоградская область</p></a>
					<a href="#!"><p>Спутниковый интернет в Волгоградской области</p></a>
					<a href="#!"><p>Тарифы</p></a>
				</div>
			</div>
			<hr class="hr">
			<div class="confident">
				<p>ПОЛИТИКА КОНФИДЕНЦИАЛЬНОСТИ <a href="#!"><img src="<?php echo get_template_directory_uri()?>/assets/img/confedential.png" alt="cfd"></a> ПОЛЬЗОВАТЕЛЬСКОЕ СОГЛАШЕНИЕ</p>
			</div>
		</div>
	</section>

	<section class="promo">
		<div class="container">
			<div class="promo-code">
				<h2>
					ПОЛУЧИТЕ ПРОМОКОД СО СКИДКОЙ 1000 РУБЛЕЙ
				</h2>
				<p>Оставьте ваш мобильный телефон и мы вышлем вам промокод со скидкой по СМС. Что бы воспользоваться промокодом и получить скидку, просто укажите данный код при заказе. Если вы хотите заказать установку со скидкой сейчас, оставьте ваши контакты через данную форму и мы с вами свяжемся.</p>
				<form action="input.php" class="form-promo">
					<input type="text" name="txt" placeholder="Ваше имя">
					<input type="tel" name="tel" class="form-tel" placeholder="Контактный телефон">
					<input type="mail" name="mail" class="form-mail" placeholder="E-mail">
					<div class="form-promo-block">
						<input type="checkbox" name="box">
						<p>Согласие на обработку персональных данных</p>
					</div>
				</form>
				<a class="button button-grey" href="#!">Узнать сейчас</a>
			</div>
		</div>
	</section>

	<section class="reviews-main">
		<div class="container">
			<div class="reviews-all">
				<div class="review-faivorite">
					<div class="links-title">
						<h2><a href="#!">ОТЗЫВЫ</a></h2>
					</div>
					<img src="<?php echo get_template_directory_uri()?>/assets/img/comma.svg" alt="">
					<div class="comment-main">
			            Установили интернет в частный дом, теперь у нас есть хороший интернет. Ютуб грузится моментально, дети смотрят мультики и можно играть в онлайн игры на ps4. Скорость как в квартире. Рекомендую 
					</div>
					<div class="user-avatar"><img src="<?php echo get_template_directory_uri()?>/assets/img/user.svg" alt=""></div>

					<div class="user-header">
						<span class="user-name">Владислав</span><br>
						<time class="comment-date" datetime="2019-03-18">18 марта 2019, 15:29</time>
					</div>

				</div>
			</div>
		</div>
	</section>
	
	<hr class="hr">

	<section>
		<div class="container">
			<div class="photo">
				<div class="links-title">
					<h2><a href="#!">Фото</a></h2>
				</div>
				<hr class="dash">
				<div class="photo-block heading">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/internet-1.webp" alt="Internet">
				
					<img src="<?php echo get_template_directory_uri()?>/assets/img/internet-2.webp" alt="Internet">

					<img src="<?php echo get_template_directory_uri()?>/assets/img/internet-3.webp" alt="Internet">

					<img src="<?php echo get_template_directory_uri()?>/assets/img/internet-4.webp" alt="Internet">
				</div>
			</div>
		</div>
	</section>
	
	<hr class="hr">
		
	<section>
		<div class="container">
			<div class="contacts">
				<div class="links-title">
					<h2><a href="#!">КОНТАКТЫ</a></h2>	
				</div>
				<hr class="dash">
				<div class="location-info">
					<img src="<?php echo get_template_directory_uri()?>/assets/img/pin.svg" alt="loc">
					<h3>Адрес</h3>
					<p>район Ворошиловский, ул.Козловская, 9 Волгоград Россия офис</p>
				</div>
				<!-- <map name="map">
					
				</map> -->
				<div class="contact-blocks">
					<div class="phone">
						<div class="contact-icon-label">
							<img src="<?php echo get_template_directory_uri()?>/assets/img/call.svg" alt="phone">
							<h3>Телефоны</h3>
						</div>
						<div class="phone-links">
							<p>+7 (8442) 61-28-01</p>
							<p>+7 (904) 361-72-36</p>
						</div>
					</div>
					<div class="mail">
						<div class="contact-icon-label">
							<img src="<?php echo get_template_directory_uri()?>/assets/img/email.svg" alt="mail">
							<h3>E-MAIL</h3>
						</div>
						<a href="#!" class="mail-link">info@volga-internet.ru</a>
					</div>	
				</div>
			</div>
		</div>
	</section>

	<hr class="hr">
</main>
		

<?php
get_footer();
