<?php
get_header();
?>

<section class="typical-services">
	<div class="container">
		<div class="section-title">
			<h1>Фото</h1>
			<hr class="dash">
		</div>
	</div>
</section>

<section class="monting-photo">
	<div class="container">
		<div class="mounting-title">
			<a href=""><h2>Фото выполненных монтажей</h2></a>
			<i class="update-time">обновлен 26 февраля 2019</i>
		</div>
		
		<div class="photo-block heading">
			<img src="<?php echo get_template_directory_uri()?>/assets/img/internet-1.webp" alt="Internet">
		
			<img src="<?php echo get_template_directory_uri()?>/assets/img/internet-2.webp" alt="Internet">

			<img src="<?php echo get_template_directory_uri()?>/assets/img/internet-3.webp" alt="Internet">

			<img src="<?php echo get_template_directory_uri()?>/assets/img/internet-4.webp" alt="Internet">
		</div>
	</div>
</section>
<hr class="hr">

<?php
get_footer();