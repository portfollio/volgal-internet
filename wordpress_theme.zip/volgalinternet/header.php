<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<header>
		<div class="container">
			<div class="contact-info">
				<div class="contact-info-left">
					<img src="assets/img/phone.svg" alt="" class="">
					<span class="phone-numbers">+7 8442 61-28-01</span>
					<span>+7 904 361-72-36</span>
				</div>
				<div class="contact-info-right">
					<a href="#!">
						<div class="feedback feedback-phone">
							<img src="assets/img/call.svg" alt="">
							<span>Бесплатная консультация</span>
						</div>
					</a>
					<a href="#!">
						<div class="feedback feedback-mail">
							<img src="assets/img/email.svg" alt="">
							<span>INFO@VOLGA-INTERNET.RU</span> 
						</div>
					</a>		
				</div>
			</div>
			<hr class="hr">
			<div class="heading clearfix">
				<img src="<?php echo get_template_directory_uri()?>assets/img/logo.png" alt="Golden" class="logo">
				<nav>
					<ul class="menu">
						<li>
							<a href="./index.php">Главная</a>
						</li>
						<li>
							<a href="./internet-to-dacha.php">Интернет на дачу</a>
						</li>
						<li>
							<a href="./internet-to-village.php">Интернет в деревне</a>
						</li>
						<li>
							<a href="./rates.php">Тарифы</a>
						</li>
						<li>
							<a href="./photo.php">Фото</a>
						</li>
						<li>
							<a href="./reviews.php">Отзывы</a>
						</li>
						<li>
							<a href="./contacts.php">Контакты</a>
						</li>
					</ul>
				</nav>
			</div>
		</div>
	</header>