<?php
get_header();
?>

<section class="typical-services">
	<div class="container">
		<div class="section-title">
			<h1>Тарифы</h1>
			<hr class="dash">
		</div>
	</div>
</section>

<section class="rates-typical">
	<div class="container">
		<div class="operators">
			<div class="operator operator-megaphone">
				<img src="<?php echo get_template_directory_uri()?>/assets/img/megaphone.png" alt="megaphone">
				<div class="operator-block">
					<div class="operator-block-speed">
						<h3>Оператор Мегафон</h3>
						<p>скорость до 100 мбит/с</p>
					</div>
					<hr class="line">	
					<div class="operator-block-rate">
						<h4>800₽/мес</h4>
						<p>Тариф без ограничений</p>
						<span>БЕЗЛИМИТНЫЙ</span>
					</div>
					<hr class="line">
				</div>
			</div>
			<div class="operator operator-tele">
				<img src="<?php echo get_template_directory_uri()?>/assets/img/tele2.png" alt="tele">
				<div class="operator-block">
					<div class="operator-block-speed">
						<h3>Оператор Теле2</h3>
						<p>скорость до 100 мбит/с</p>
					</div>
					<hr class="line">
					<div class="operator-block-rate">
						<h4>800₽/мес</h4>
						<p>Тариф без ограничений</p>
						<span>БЕЗЛИМИТНЫЙ</span>
					</div>
					<hr class="line">	
				</div>
			</div>
			<div class="operator operator-beeline">
				<img src="<?php echo get_template_directory_uri()?>/assets/img/beeline.png" alt="beeline">
				<div class="operator-block">
					<div class="operator-block-speed">
						<h3>Оператор Билайн</h3>
						<p>скорость до 100 мбит/с</p>
					</div>
					<hr class="line">
					<div class="operator-block-rate">
						<h4>800₽/мес</h4>
						<p>Тариф без ограничений</p>
						<span>БЕЗЛИМИТНЫЙ</span>
					</div>	
					<hr class="line">
				</div>
			</div>
		</div>
		<span class="button button-typing-black">Оставить заявку</span>
	</div>
</section>

<hr class="hr">

<?php
get_footer();