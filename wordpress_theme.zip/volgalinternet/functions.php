<?php

function volgalinternet_setup() {
	load_theme_textdomain('volgalinternet');

	add_theme_support( 'menus' );

	register_nav_menus(
		array(
			'header-menu' => 'Основное меню',
			'other-menu' => 'Другое меню'
		)
	);
}
add_action ('after_setup_theme', 'volgalinternet_setup');

function volgalinternet_scripts() {

	wp_enqueue_style( 'volgalinternet-fonts', "https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,400;1,700&display=swap" );

	wp_enqueue_style( 'volgalinternet-normalize', get_template_directory_uri() . "assets/css/normalize.css" );

	wp_enqueue_style( 'volgalinternet-main', get_stylesheet_uri() );

	// wp_style_add_data( 'volgalinternet-style', 'rtl', 'replace' );

	// wp_enqueue_script( 'volgalinternet-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'volgalinternet_scripts' );
