<?php
get_header();
?>

	<main>
		<section class="typical-services">
			<div class="container">
				<div class="section-title">
					<h1>Отзывы</h1>
					<hr class="dash">
				</div>
			</div>
		</section>
		<section class="reviews-typing">
			<div class="container">
				<span class="button button-review">Оставить отзыв</span>
				<div class="reviews">
					<div class="review">
						<div class="review-header">
							<div class="user-avatar-typing">
								<img src="<?php echo get_template_directory_uri()?>/assets/img/user.svg" alt="user">
							</div>
							<div class="author-info">
								<span class="author">Владислав</span>
								<time class="infoDigits comment-item__time" datetime="2019-03-18">
					         	18 марта 2019, 15:29
					            </time>	
							</div>
						</div>
						<div class="review-footer">
							<div class="comment comment-typing-text">
				                Установили интернет в частный дом, теперь у нас есть хороший интернет. Ютуб грузится моментально, дети смотрят мультики и можно играть в онлайн игры на ps4. Скорость как в квартире. Рекомендую
				            </div>
				            <a class="answer-button comment-typing-link">комментировать</a>
				        </div>
					</div>
				</div>
			</div>
		</section>
	</main>

<?php
get_footer();